﻿using System;

namespace Methods___Simple_Method
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ReadKey();
        }

        static string Speak (string Sound)
        {
            string Dog = ();
            string Monkey = ();
            Console.WriteLine("Enter a type of animal.");
            string Animal = Console.ReadLine();

            if (Animal = "dog")
            {
                Console.WriteLine("BARK BARK");
            }
            else if (Animal = "monkey")
            {
                Console.WriteLine("GRUNTING");
            }
            else if (Animal = "goat")
            {
                Console.WriteLine("BLEAT");
            }
            else
            {
                // INVALID
            }
            Console.ReadKey();
            // i rewatched the lectures about how to do methods and I am still very confused.
            // i am hoping to get clarity on this in class tuesday!
        }
    }
}
